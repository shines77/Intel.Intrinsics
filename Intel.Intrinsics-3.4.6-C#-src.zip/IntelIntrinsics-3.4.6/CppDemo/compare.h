#pragma once

void testCompare();