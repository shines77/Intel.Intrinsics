#pragma once
void testImageBrightness();