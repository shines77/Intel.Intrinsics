#pragma once

bool testQuaternionMultuply();